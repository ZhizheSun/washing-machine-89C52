#include<reg52.h>
unsigned char u8;
unsigned char u16;
#define uint unsigned int
#define uchar unsigned char

int mod1,mod2,way,k = 0;
/*int mod1[] = 
{
	0,1,2
};
int mod2[] = 
{
	0,1,2,3
};*/
uchar code dat[]={0};
//sbit led0 = P0^0; //��Դ
sbit led1 = P0^1; //��׼
sbit led2 = P0^2; //����
sbit led3 = P0^3; //ϴ
sbit led4 = P0^4; //Ư
sbit led5 = P0^5; //��

sbit L0 = P1^0;
sbit L1 = P1^1;
sbit L2 = P1^2;
sbit L3 = P1^3;
sbit L4 = P1^4;
sbit L5 = P1^5;
sbit L6 = P1^6;
sbit L7 = P1^7;
sbit L8 = P2^4;
sbit L9 = P2^5;
sbit L10 = P2^6;
sbit L11 = P2^7;

sbit K0 = P3^0; //������ֹͣ
sbit K1 = P3^1; //����1
sbit K2 = P3^2; //����2
sbit K3 = P3^3;//��Դ

sbit M0 = P2^0; //�����
sbit M1 = P2^1; //�����

sbit I0 =P2^2; //�̵���

void delay_ms(uint n)
{
	uint i = 0,j = 0;
	for(i=0;i<n;i++)
		for(j=0;j<123;j++);
}

void mod()	//ģʽѡ��
{
	//if(K1==0&&K2==0)
	//{
		if(K1==1)
		{
			delay_ms(500);
			mod1++;
			mod2 = 0;
			if(mod1==3){
				mod1 = 0;}
			L0 = mod1%2;
			L1 = mod1/2;
			L4 = mod2%2;
			L5 = mod2/2;
		}
		if(K2==1)
		{
			delay_ms(500);
			mod2++;
			mod1 = 0;
			if(mod2==4){
				mod2 = 0;}
			L0 = mod1%2;
			L1 = mod1/2;
			L4 = mod2%2;
			L5 = mod2/2;
		}
	//}
}
void select()	//ģʽ�ж�
{
	//if(K0==1)
	//{
		if(mod1==0)
		{
			/*switch(mod2)
			{
				case 1:
					way = 3;
					break;
				case 2:
					way = 4;
					break;
				case 3:
					way = 5;
					break;
			}*/
			if(mod2==1){
				way = 3;}
			if(mod2==2){
				way = 4;}
			if(mod2==3){
				way = 5;}
		}
		if(mod1==1){
			way = 1;}
		if(mod1==2){
			way = 2;}
	//}
}

void time_read(char k)
{
	int min,sec,sec1,sec10;
	min = k/60;
	sec = k%60;
	sec1 = sec%10;
	sec10 = sec/10;
	L0 = min%2;
	L1 = min/2;

	L8 = sec1%2;
	L9 = (sec1/2)%2;
	L10 = ((sec1/2)/2)%2;
	L11 = (((sec1/2)/2)/2)%2;

	L4 = sec10%2;
	L5 = (sec10/2)%2;
	L6 = ((sec10/2)/2)%2;
	L7 = (((sec10/2)/2)/2)%2;
}
void open()
{
	uint i = 0;
	I0 = 1;
	for(i=0;i<5;i++)
	{
		time_read(k);
		delay_ms(1000);
		k--;
	}
	I0 = 0;
}

void wash()
{
	uint i = 0;
	for(i=0;i<38;i++)
	{
		M0 = 1;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		time_read(k);
		k++;
		M0 = 0;
		M1 = 1;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		time_read(k);
		k++;
	}	
}
void potch()
{
	uint i = 0;
	for(i=0;i<15;i++)
	{
		M0 = 1;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		time_read(k);
		k++;
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 1;
		delay_ms(500);
		time_read(k);
		k++;
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		time_read(k);
		k++;
	}	
}
void dep()
{
	uint i = 0;
	M0 = 1;
	M1 = 0;
	for(i=0;i<15;i++)
	{
		time_read(k);
		k++;
		delay_ms(1000);
	}
}
void way1()	//��׼ϴ
{
	led1 = 1;
	k = 0;
	open();
	open();
	k = 0;
	wash();
	wash();
	k = 0;
	potch();
	potch();
	k = 0;
	dep();
	dep();
	led1 = 0;
}

void way2()	//����ϴ
{
	led2 = 1;
	open();
	wash();
	potch();
	dep();
	led2 = 0;
}
void way3()
{
	led3 = 1;
	wash();
	led3 = 0;
}
void way4()
{
	led4 = 1;
	potch();
	led4 = 0;	
}
void way5()
{
	led5 = 1;
	dep();
	led5 = 0;
}

void time_int()
{
	P1 = 0x00;
	L8 = 0;
	L9 = 0;
	L10 = 0;
	L11 = 0;
}

void main()
{
	P0 = 0x00;
	P1 = 0x00;
	P2 = 0x00;
	P3 = 0x00;
	if(K3==1)
	{
		while(1)
		{
			time_int;
			if(K0==0)
			{
				mod();
			}
			if(K0==1)
			{
				select();
				switch(way)
				{
					case 1:
						way1();
						break;
					case 2:
						way2();
						break;
					case 3:
						way3();
						break;
					case 4:
						way4();
						break;
					case 5:
						way5();
						break;
					default:
						break;
				}
			}
			way = 0;
		}
	}
}
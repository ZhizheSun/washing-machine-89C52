#include<reg52.h>
unsigned char u8;
unsigned char u16;
#define uint unsigned int
#define uchar unsigned char

int mod1,mod2,way = 0;
/*int mod1[] = 
{
	0,1,2
};
int mod2[] = 
{
	0,1,2,3
};*/
uchar code dat[]={0};
//sbit led0 = P0^0; //��Դ
sbit led1 = P0^1; //��׼
sbit led2 = P0^2; //����
sbit led3 = P0^3; //ϴ
sbit led4 = P0^4; //Ư
sbit led5 = P0^5; //��

sbit L1 = P1^0;
sbit L2 = P1^1;
sbit L3 = P1^4;
sbit L4 = P1^5;

sbit K0 = P3^0; //������ֹͣ
sbit K1 = P3^1; //����1
sbit K2 = P3^2; //����2
//sbit K3 = P3^3 //��Դ

sbit M0 = P2^0; //�����
sbit M1 = P2^1; //�����

sbit I0 =P2^2; //�̵���

void delay_ms(uint n)
{
	uint i = 0,j = 0;
	for(i=0;i<n;i++)
		for(j=0;j<123;j++);
}

void mod()	//ģʽѡ��
{
	if(K1==0&&K2==0)
	{
		if(K1==1)
		{
			mod1++;
			if(mod1==3){
				mod1 = 0;}
			L1 = mod1%2;
			L2 = mod1/2;
		}
		if(K2==1)
		{
			mod2++;
			if(mod2==4){
				mod2 = 0;}
			L3 = mod2%2;
			L4 = mod2/2;
		}
	}
}
void select()	//ģʽ�ж�
{
	//if(K0==1)
	//{
		if(mod1==0)
		{
			/*switch(mod2)
			{
				case 1:
					way = 3;
					break;
				case 2:
					way = 4;
					break;
				case 3:
					way = 5;
					break;
			}*/
			if(mod2==1){
				way = 3;}
			if(mod2==2){
				way = 4;}
			if(mod2==3){
				way = 5;}
		}
		if(mod1==1){
			way = 1;}
		if(mod1==2){
			way = 2;}
	//}
}

void open()
{
	I0 = 1;
	delay_ms(5000);
	I0 = 0;
}

void wash()
{
	uint i = 0;
	for(i=0;i<38;i++)
	{
		M0 = 1;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 1;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(500);
	}	
}
void potch()
{
	uint i = 0;
	for(i=0;i<15;i++)
	{
		M0 = 1;
		M1 = 0;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(1000);
		M0 = 0;
		M1 = 1;
		delay_ms(500);
		M0 = 0;
		M1 = 0;
		delay_ms(1000);
	}	
}
void dep()
{
	M0 = 1;
	M1 = 0;
	delay_ms(25000);
}
void way1()	//��׼ϴ
{
	led1 = 1;
	open();
	open();
	wash();
	wash();
	potch();
	potch();
	dep();
	dep();
	led1 = 0;
}

void way2()	//����ϴ
{
	led2 = 1;
	open();
	wash();
	potch();
	dep();
	led2 = 0;
}
void way3()
{
	led3 = 1;
	wash();
	led3 = 0;
}
void way4()
{
	led4 = 1;
	potch();
	led4 = 0;	
}
void way5()
{
	led5 = 1;
	dep();
	led5 = 0;
}
void main()
{
	P0 = 0x00;
	P1 = 0x00;
	P2 = 0x00;
	P3 = 0x00;
	while(1)
	{
		if(K0==0)
		{
			mod();
		}
		if(K0==1)
		{
			select();
			switch(way)
			{
				case 1:
					way1();
					break;
				case 2:
					way2();
					break;
				case 3:
					way3();
					break;
				case 4:
					way4();
					break;
				case 5:
					way5();
					break;
				default:
					break;
			}
		}
		way = 0;
	}
}